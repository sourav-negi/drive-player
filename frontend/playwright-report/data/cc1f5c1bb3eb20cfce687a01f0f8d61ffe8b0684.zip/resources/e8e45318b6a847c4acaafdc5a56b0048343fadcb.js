(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/lib/api.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// ------------------------------------------------------------------
// drive-pleya — typed API client with cold-start awareness
// ------------------------------------------------------------------
__turbopack_context__.s([
    "ApiError",
    ()=>ApiError,
    "api",
    ()=>api
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const API_BASE = ("TURBOPACK compile-time value", "http://localhost:8000") || "http://localhost:8000";
// Render free tier wakes from sleep in 30–60 s.  We use a long timeout
// so the server has a chance to wake up instead of timing out too early.
const COLD_START_TIMEOUT_MS = 45_000;
const NORMAL_TIMEOUT_MS = 12_000;
class ApiError extends Error {
    status;
    coldStart;
    constructor(status, message, coldStart = false){
        super(message), this.status = status, this.coldStart = coldStart;
        this.name = "ApiError";
    }
}
async function fetchApi(path, options) {
    const timeoutMs = options?.timeoutMs ?? NORMAL_TIMEOUT_MS;
    const maxRetries = options?.retries ?? 0;
    let lastError = null;
    for(let attempt = 0; attempt <= maxRetries; attempt++){
        // small delay between retries (increase with each attempt)
        if (attempt > 0) {
            await new Promise((r)=>setTimeout(r, attempt * 2_000));
        }
        const controller = new AbortController();
        const timer = setTimeout(()=>controller.abort(), timeoutMs);
        try {
            const url = `${API_BASE}${path}`;
            const res = await fetch(url, {
                signal: controller.signal,
                headers: {
                    "Content-Type": "application/json",
                    ...options?.headers
                },
                ...options
            });
            clearTimeout(timer);
            if (!res.ok) {
                let body = "";
                try {
                    body = await res.text();
                } catch  {}
                throw new ApiError(res.status, body || res.statusText);
            }
            return res.json();
        } catch (err) {
            clearTimeout(timer);
            // already an ApiError (known HTTP error) — don't retry
            if (err instanceof ApiError) throw err;
            lastError = err instanceof Error ? err : new Error(String(err));
            // AbortError with timeout → likely cold start
            const isTimeout = err instanceof DOMException && err.name === "AbortError";
            // Only retry on timeouts (cold starts); network errors get
            // retried once, then marked as potential cold starts.
            if (isTimeout || attempt < maxRetries && !(err instanceof ApiError)) {
                continue;
            }
        }
    }
    // All retries exhausted — surface as a cold-start-aware error
    throw new ApiError(0, lastError?.message || "request failed", true);
}
const api = {
    /** List videos and folders (optionally scoped to a folder). */ getFiles (folderId) {
        const qs = folderId ? `?folder_id=${encodeURIComponent(folderId)}` : "";
        return fetchApi(`/api/files${qs}`, {
            timeoutMs: COLD_START_TIMEOUT_MS,
            retries: 2
        });
    },
    /** Get metadata for a single file. */ getFile (id) {
        return fetchApi(`/api/files/${encodeURIComponent(id)}`, {
            timeoutMs: COLD_START_TIMEOUT_MS,
            retries: 2
        });
    },
    /** Return the URL that the <video> element should use as its src. */ getStreamUrl (fileId) {
        return `${API_BASE}/api/files/${encodeURIComponent(fileId)}/stream`;
    },
    /** Return a thumbnail proxy URL (backend fetches it with OAuth). */ getThumbnailUrl (fileId) {
        return `${API_BASE}/api/files/${encodeURIComponent(fileId)}/thumbnail`;
    },
    /** Quick health-check ping — used to detect cold starts. */ async healthCheck () {
        try {
            const controller = new AbortController();
            const timer = setTimeout(()=>controller.abort(), 8_000);
            const res = await fetch(`${API_BASE}/api/health`, {
                signal: controller.signal
            });
            clearTimeout(timer);
            return res.ok;
        } catch  {
            return false;
        }
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/progressStore.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// ------------------------------------------------------------------
// drive-pleya — localStorage-based watch progress
// ------------------------------------------------------------------
__turbopack_context__.s([
    "progressStore",
    ()=>progressStore
]);
const STORAGE_KEY = "drive-pleya:progress";
function loadAll() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    try {
        const raw = localStorage.getItem(STORAGE_KEY);
        return raw ? JSON.parse(raw) : {};
    } catch  {
        return {};
    }
}
function saveAll(data) {
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch  {
    /* quota exceeded */ }
}
const progressStore = {
    /** Get all progress entries. */ getAll () {
        return loadAll();
    },
    /** Get progress for a single video. */ get (fileId) {
        const all = loadAll();
        return all[fileId] ?? null;
    },
    /** Save progress for a video. */ save (fileId, position, duration) {
        const all = loadAll();
        const pct = duration > 0 ? Math.round(position / duration * 1000) / 10 : 0;
        const entry = {
            position,
            duration,
            percentage: pct,
            completed: pct > 90,
            lastUpdated: new Date().toISOString()
        };
        all[fileId] = entry;
        saveAll(all);
        return entry;
    },
    /** Delete progress for a video. */ delete (fileId) {
        const all = loadAll();
        if (fileId in all) {
            delete all[fileId];
            saveAll(all);
            return true;
        }
        return false;
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/format.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// ------------------------------------------------------------------
// drive-pleya — display helpers
// ------------------------------------------------------------------
/**
 * Format a raw filename for display.
 *   001_hello_video.mp4  →  1. Hello Video
 */ __turbopack_context__.s([
    "formatTitle",
    ()=>formatTitle
]);
function formatTitle(filename) {
    // strip extension
    const dot = filename.lastIndexOf(".");
    const stem = dot > 0 ? filename.slice(0, dot) : filename;
    // match patterns like "001_hello_video" or "01_something"
    const match = stem.match(/^0*(\d+)_(.+)$/);
    if (match) {
        const num = parseInt(match[1], 10);
        const name = match[2].replace(/_+/g, " ") // underscores → spaces
        .replace(/\b\w/g, (c)=>c.toUpperCase()); // title case
        return `${num}. ${name}`;
    }
    // no number prefix — just clean up underscores
    return stem.replace(/_+/g, " ");
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useVideoPlayer.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useVideoPlayer",
    ()=>useVideoPlayer
]);
// ------------------------------------------------------------------
// drive-pleya — video player state management
// ------------------------------------------------------------------
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
const SPEEDS = [
    0.5,
    0.75,
    1,
    1.25,
    1.5,
    2,
    2.5,
    3,
    3.5,
    4
];
const STORAGE_KEY_VOLUME = "drive-pleya:volume";
const STORAGE_KEY_SPEED = "drive-pleya:speed";
function loadStored(key, fallback) {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    try {
        const raw = localStorage.getItem(key);
        return raw ? JSON.parse(raw) : fallback;
    } catch  {
        return fallback;
    }
}
function saveStored(key, value) {
    try {
        localStorage.setItem(key, JSON.stringify(value));
    } catch  {
    /* quota exceeded */ }
}
function useVideoPlayer(videoRef, fullscreenRef) {
    _s();
    const [playing, setPlaying] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [currentTime, setCurrentTime] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [duration, setDuration] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [volume, setVolumeState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "useVideoPlayer.useState": ()=>loadStored(STORAGE_KEY_VOLUME, 1)
    }["useVideoPlayer.useState"]);
    const [muted, setMuted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [speed, setSpeedState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "useVideoPlayer.useState": ()=>loadStored(STORAGE_KEY_SPEED, 1)
    }["useVideoPlayer.useState"]);
    const [isFullscreen, setIsFullscreen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [buffering, setBuffering] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // sync fullscreen state with browser (handles Esc key)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useVideoPlayer.useEffect": ()=>{
            const handler = {
                "useVideoPlayer.useEffect.handler": ()=>setIsFullscreen(!!document.fullscreenElement)
            }["useVideoPlayer.useEffect.handler"];
            document.addEventListener("fullscreenchange", handler);
            return ({
                "useVideoPlayer.useEffect": ()=>document.removeEventListener("fullscreenchange", handler)
            })["useVideoPlayer.useEffect"];
        }
    }["useVideoPlayer.useEffect"], []);
    // sync from video element events
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useVideoPlayer.useEffect": ()=>{
            const el = videoRef.current;
            if (!el) return;
            const onPlay = {
                "useVideoPlayer.useEffect.onPlay": ()=>{
                    setPlaying(true);
                    setBuffering(false);
                }
            }["useVideoPlayer.useEffect.onPlay"];
            const onPause = {
                "useVideoPlayer.useEffect.onPause": ()=>setPlaying(false)
            }["useVideoPlayer.useEffect.onPause"];
            const onEnded = {
                "useVideoPlayer.useEffect.onEnded": ()=>setPlaying(false)
            }["useVideoPlayer.useEffect.onEnded"];
            const onTime = {
                "useVideoPlayer.useEffect.onTime": ()=>setCurrentTime(el.currentTime)
            }["useVideoPlayer.useEffect.onTime"];
            const onDuration = {
                "useVideoPlayer.useEffect.onDuration": ()=>setDuration(el.duration || 0)
            }["useVideoPlayer.useEffect.onDuration"];
            const onVolume = {
                "useVideoPlayer.useEffect.onVolume": ()=>{
                    setVolumeState(el.volume);
                    setMuted(el.muted);
                }
            }["useVideoPlayer.useEffect.onVolume"];
            const onWaiting = {
                "useVideoPlayer.useEffect.onWaiting": ()=>setBuffering(true)
            }["useVideoPlayer.useEffect.onWaiting"];
            const onCanPlay = {
                "useVideoPlayer.useEffect.onCanPlay": ()=>setBuffering(false)
            }["useVideoPlayer.useEffect.onCanPlay"];
            el.addEventListener("play", onPlay);
            el.addEventListener("pause", onPause);
            el.addEventListener("ended", onEnded);
            el.addEventListener("timeupdate", onTime);
            el.addEventListener("durationchange", onDuration);
            el.addEventListener("volumechange", onVolume);
            el.addEventListener("waiting", onWaiting);
            el.addEventListener("canplay", onCanPlay);
            // init
            setVolumeState(el.volume);
            setMuted(el.muted);
            if (el.duration) setDuration(el.duration);
            return ({
                "useVideoPlayer.useEffect": ()=>{
                    el.removeEventListener("play", onPlay);
                    el.removeEventListener("pause", onPause);
                    el.removeEventListener("ended", onEnded);
                    el.removeEventListener("timeupdate", onTime);
                    el.removeEventListener("durationchange", onDuration);
                    el.removeEventListener("volumechange", onVolume);
                    el.removeEventListener("waiting", onWaiting);
                    el.removeEventListener("canplay", onCanPlay);
                }
            })["useVideoPlayer.useEffect"];
        }
    }["useVideoPlayer.useEffect"], [
        videoRef
    ]);
    // ------- actions (direct, no guards) -------
    const togglePlay = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useVideoPlayer.useCallback[togglePlay]": ()=>{
            const el = videoRef.current;
            if (!el) return;
            if (el.paused) {
                el.play().catch({
                    "useVideoPlayer.useCallback[togglePlay]": ()=>{}
                }["useVideoPlayer.useCallback[togglePlay]"]);
            } else {
                el.pause();
            }
        }
    }["useVideoPlayer.useCallback[togglePlay]"], [
        videoRef
    ]);
    const seek = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useVideoPlayer.useCallback[seek]": (seconds)=>{
            const el = videoRef.current;
            if (el) el.currentTime = seconds;
        }
    }["useVideoPlayer.useCallback[seek]"], [
        videoRef
    ]);
    const skip = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useVideoPlayer.useCallback[skip]": (delta)=>{
            const el = videoRef.current;
            if (el) el.currentTime = el.currentTime + delta;
        }
    }["useVideoPlayer.useCallback[skip]"], [
        videoRef
    ]);
    const setVolumeAndSave = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useVideoPlayer.useCallback[setVolumeAndSave]": (v)=>{
            const el = videoRef.current;
            if (el) {
                el.volume = v;
                el.muted = v === 0;
            }
            setVolumeState(v);
            setMuted(v === 0);
            saveStored(STORAGE_KEY_VOLUME, v);
        }
    }["useVideoPlayer.useCallback[setVolumeAndSave]"], [
        videoRef
    ]);
    const toggleMute = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useVideoPlayer.useCallback[toggleMute]": ()=>{
            const el = videoRef.current;
            if (!el) return;
            el.muted = !el.muted;
            setMuted(el.muted);
        }
    }["useVideoPlayer.useCallback[toggleMute]"], [
        videoRef
    ]);
    const setSpeed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useVideoPlayer.useCallback[setSpeed]": (s)=>{
            const el = videoRef.current;
            if (el) el.playbackRate = s;
            setSpeedState(s);
            saveStored(STORAGE_KEY_SPEED, s);
        }
    }["useVideoPlayer.useCallback[setSpeed]"], [
        videoRef
    ]);
    const cycleSpeed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useVideoPlayer.useCallback[cycleSpeed]": (dir)=>{
            const idx = SPEEDS.indexOf(speed);
            const next = (idx + dir + SPEEDS.length) % SPEEDS.length;
            setSpeed(SPEEDS[next]);
        }
    }["useVideoPlayer.useCallback[cycleSpeed]"], [
        speed,
        setSpeed
    ]);
    const toggleFullscreen = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useVideoPlayer.useCallback[toggleFullscreen]": ()=>{
            const target = fullscreenRef?.current ?? videoRef.current;
            if (!target) return;
            if (!document.fullscreenElement) {
                target.requestFullscreen().catch({
                    "useVideoPlayer.useCallback[toggleFullscreen]": ()=>{}
                }["useVideoPlayer.useCallback[toggleFullscreen]"]);
            } else {
                document.exitFullscreen().catch({
                    "useVideoPlayer.useCallback[toggleFullscreen]": ()=>{}
                }["useVideoPlayer.useCallback[toggleFullscreen]"]);
            }
        }
    }["useVideoPlayer.useCallback[toggleFullscreen]"], [
        videoRef,
        fullscreenRef
    ]);
    return {
        playing,
        buffering,
        currentTime,
        duration,
        volume,
        muted,
        speed,
        isFullscreen,
        togglePlay,
        seek,
        skip,
        setVolume: setVolumeAndSave,
        toggleMute,
        setSpeed,
        cycleSpeed,
        toggleFullscreen,
        SPEEDS
    };
}
_s(useVideoPlayer, "s3juOHexx0upaRL4lzg8dqfidKc=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useWatchProgress.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useWatchProgress",
    ()=>useWatchProgress
]);
// ------------------------------------------------------------------
// drive-pleya — watch progress tracking (localStorage)
// ------------------------------------------------------------------
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$progressStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/progressStore.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
const SAVE_INTERVAL_MS = 10_000; // periodic save while playing
const RESUME_THRESHOLD_S = 5; // only ask to resume if > 5 s in
function useWatchProgress({ fileId, videoRef, onProgressLoaded }) {
    _s();
    const lastSavedRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0);
    const durationRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0);
    // ------------------------------------------------------------------
    // load saved progress on mount → seek if applicable
    // ------------------------------------------------------------------
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useWatchProgress.useEffect": ()=>{
            const saved = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$progressStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["progressStore"].get(fileId);
            if (saved) {
                onProgressLoaded?.(saved);
                if (saved.position > RESUME_THRESHOLD_S && videoRef.current) {
                    videoRef.current.currentTime = saved.position;
                }
            }
        }
    }["useWatchProgress.useEffect"], [
        fileId
    ]); // eslint-disable-line react-hooks/exhaustive-deps
    // ------------------------------------------------------------------
    // periodic save (every SAVE_INTERVAL_MS while playing)
    // ------------------------------------------------------------------
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useWatchProgress.useEffect": ()=>{
            const interval = setInterval({
                "useWatchProgress.useEffect.interval": ()=>{
                    const el = videoRef.current;
                    if (!el || el.paused) return;
                    const pos = el.currentTime;
                    const dur = el.duration || durationRef.current;
                    if (Math.abs(pos - lastSavedRef.current) < 0.5) return;
                    lastSavedRef.current = pos;
                    durationRef.current = dur;
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$progressStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["progressStore"].save(fileId, pos, dur);
                }
            }["useWatchProgress.useEffect.interval"], SAVE_INTERVAL_MS);
            return ({
                "useWatchProgress.useEffect": ()=>clearInterval(interval)
            })["useWatchProgress.useEffect"];
        }
    }["useWatchProgress.useEffect"], [
        fileId,
        videoRef
    ]);
    // ------------------------------------------------------------------
    // save on pause
    // ------------------------------------------------------------------
    const saveOnPause = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useWatchProgress.useCallback[saveOnPause]": ()=>{
            const el = videoRef.current;
            if (!el) return;
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$progressStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["progressStore"].save(fileId, el.currentTime, el.duration || durationRef.current);
        }
    }["useWatchProgress.useCallback[saveOnPause]"], [
        fileId,
        videoRef
    ]);
    return {
        saveOnPause
    };
}
_s(useWatchProgress, "mRrEb08+7IBRwbu7beJ10vxNyyk=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/SeekBar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SeekBar",
    ()=>SeekBar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
// ------------------------------------------------------------------
// drive-pleya — clickable / draggable seek bar (mouse + touch)
// ------------------------------------------------------------------
"use client";
;
function fmt(seconds) {
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60);
    return `${m}:${s.toString().padStart(2, "0")}`;
}
function SeekBar({ currentTime, duration, onSeek }) {
    _s();
    const barRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [dragging, setDragging] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [hoverTime, setHoverTime] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [hoverOffset, setHoverOffset] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const pct = duration > 0 ? currentTime / duration * 100 : 0;
    const posFromClientX = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "SeekBar.useCallback[posFromClientX]": (clientX)=>{
            if (!barRef.current || duration <= 0) return 0;
            const rect = barRef.current.getBoundingClientRect();
            const ratio = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
            return ratio * duration;
        }
    }["SeekBar.useCallback[posFromClientX]"], [
        duration
    ]);
    // ---- mouse ----
    const handleMouseDown = (e)=>{
        if (duration <= 0) return;
        setDragging(true);
        onSeek(posFromClientX(e.clientX));
    };
    const handleMouseMove = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "SeekBar.useCallback[handleMouseMove]": (e)=>{
            if (!barRef.current) return;
            const rect = barRef.current.getBoundingClientRect();
            const t = posFromClientX(e.clientX);
            setHoverTime(t);
            setHoverOffset(e.clientX - rect.left);
            if (dragging) onSeek(t);
        }
    }["SeekBar.useCallback[handleMouseMove]"], [
        dragging,
        onSeek,
        posFromClientX
    ]);
    const handleDragEnd = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "SeekBar.useCallback[handleDragEnd]": ()=>{
            setDragging(false);
        }
    }["SeekBar.useCallback[handleDragEnd]"], []);
    // global listeners for drag-seek (mouse)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SeekBar.useEffect": ()=>{
            if (dragging) {
                window.addEventListener("mousemove", handleMouseMove);
                window.addEventListener("mouseup", handleDragEnd);
                return ({
                    "SeekBar.useEffect": ()=>{
                        window.removeEventListener("mousemove", handleMouseMove);
                        window.removeEventListener("mouseup", handleDragEnd);
                    }
                })["SeekBar.useEffect"];
            }
        }
    }["SeekBar.useEffect"], [
        dragging,
        handleMouseMove,
        handleDragEnd
    ]);
    // ---- touch ----
    const touchIdRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const touchMovedRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const handleTouchStart = (e)=>{
        if (duration <= 0) return;
        const touch = e.changedTouches[0];
        touchIdRef.current = touch.identifier;
        touchMovedRef.current = false;
        setDragging(true);
    };
    const handleTouchMove = (e)=>{
        const touch = Array.from(e.changedTouches).find((t)=>t.identifier === touchIdRef.current);
        if (!touch || duration <= 0) return;
        touchMovedRef.current = true;
        onSeek(posFromClientX(touch.clientX));
    };
    const handleTouchEnd = (e)=>{
        const touch = Array.from(e.changedTouches).find((t)=>t.identifier === touchIdRef.current);
        // tap (no drag) — seek once on release
        if (touch && duration > 0 && !touchMovedRef.current) {
            onSeek(posFromClientX(touch.clientX));
        }
        touchIdRef.current = null;
        touchMovedRef.current = false;
        setDragging(false);
    };
    // ---- render ----
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "group relative",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-between text-[11px] sm:text-xs text-gray-700 mb-1 px-1 tabular-nums",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: fmt(currentTime)
                    }, void 0, false, {
                        fileName: "[project]/src/components/SeekBar.tsx",
                        lineNumber: 116,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: fmt(duration)
                    }, void 0, false, {
                        fileName: "[project]/src/components/SeekBar.tsx",
                        lineNumber: 117,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/SeekBar.tsx",
                lineNumber: 115,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: barRef,
                className: "relative h-6 sm:h-5 flex items-center cursor-pointer touch-none",
                onMouseDown: handleMouseDown,
                onMouseMove: (e)=>{
                    const rect = barRef.current?.getBoundingClientRect();
                    setHoverTime(posFromClientX(e.clientX));
                    if (rect) setHoverOffset(e.clientX - rect.left);
                },
                onMouseLeave: ()=>setHoverTime(null),
                onTouchStart: handleTouchStart,
                onTouchMove: handleTouchMove,
                onTouchEnd: handleTouchEnd,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute w-full h-1 sm:h-1 bg-black/20 rounded-full pointer-events-none"
                    }, void 0, false, {
                        fileName: "[project]/src/components/SeekBar.tsx",
                        lineNumber: 136,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute h-1 sm:h-1 bg-black rounded-full pointer-events-none",
                        style: {
                            width: `${Math.min(pct, 100)}%`
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/SeekBar.tsx",
                        lineNumber: 138,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute w-3.5 h-3.5 bg-black rounded-full -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none",
                        style: {
                            left: `${Math.min(pct, 100)}%`
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/SeekBar.tsx",
                        lineNumber: 143,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/SeekBar.tsx",
                lineNumber: 121,
                columnNumber: 7
            }, this),
            hoverTime !== null && !dragging && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute -top-7 text-[11px] bg-black text-white px-1.5 py-0.5 rounded pointer-events-none hidden sm:block",
                style: {
                    left: hoverOffset,
                    transform: "translateX(-50%)"
                },
                children: fmt(hoverTime)
            }, void 0, false, {
                fileName: "[project]/src/components/SeekBar.tsx",
                lineNumber: 151,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/SeekBar.tsx",
        lineNumber: 113,
        columnNumber: 5
    }, this);
}
_s(SeekBar, "fB4TUuOX/REXpWL7cbANqqoEPJU=");
_c = SeekBar;
var _c;
__turbopack_context__.k.register(_c, "SeekBar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/SpeedSelector.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SpeedSelector",
    ()=>SpeedSelector
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// ------------------------------------------------------------------
// drive-pleya — playback speed selector
// ------------------------------------------------------------------
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
function SpeedSelector({ speed, speeds, onChange }) {
    _s();
    const [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // close on outside click
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SpeedSelector.useEffect": ()=>{
            if (!open) return;
            const handler = {
                "SpeedSelector.useEffect.handler": (e)=>{
                    if (ref.current && !ref.current.contains(e.target)) {
                        setOpen(false);
                    }
                }
            }["SpeedSelector.useEffect.handler"];
            window.addEventListener("mousedown", handler);
            return ({
                "SpeedSelector.useEffect": ()=>window.removeEventListener("mousedown", handler)
            })["SpeedSelector.useEffect"];
        }
    }["SpeedSelector.useEffect"], [
        open
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: "relative",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: ()=>setOpen(!open),
                className: "h-8 px-2 rounded text-xs font-medium text-black bg-black/10 hover:bg-black/20 transition-colors",
                title: "playback speed",
                children: [
                    speed,
                    "×"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/SpeedSelector.tsx",
                lineNumber: 32,
                columnNumber: 7
            }, this),
            open && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute bottom-full mb-2 left-0 bg-white border border-gray-300 rounded-lg py-1 shadow-lg z-50",
                children: speeds.map((s)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>{
                            onChange(s);
                            setOpen(false);
                        },
                        className: `block w-full text-left px-4 py-1.5 text-xs whitespace-nowrap hover:bg-gray-100 transition-colors ${s === speed ? "text-brand font-medium" : "text-gray-700"}`,
                        children: [
                            s === speed && "• ",
                            s,
                            "×"
                        ]
                    }, s, true, {
                        fileName: "[project]/src/components/SpeedSelector.tsx",
                        lineNumber: 43,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/components/SpeedSelector.tsx",
                lineNumber: 41,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/SpeedSelector.tsx",
        lineNumber: 31,
        columnNumber: 5
    }, this);
}
_s(SpeedSelector, "wl9VvfhnMVWQ+kCekFjcRPEi3/0=");
_c = SpeedSelector;
var _c;
__turbopack_context__.k.register(_c, "SpeedSelector");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/VolumeControl.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// ------------------------------------------------------------------
// drive-pleya — volume slider + mute toggle
// ------------------------------------------------------------------
__turbopack_context__.s([
    "VolumeControl",
    ()=>VolumeControl
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function VolumeControl({ volume, muted, onVolume, onToggleMute }) {
    const vol = muted ? 0 : volume;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex items-center gap-1.5",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: onToggleMute,
                className: "h-8 w-8 flex items-center justify-center rounded text-black hover:text-gray-700 transition-colors",
                title: muted ? "unmute" : "mute",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    className: "w-4 h-4",
                    fill: "currentColor",
                    viewBox: "0 0 24 24",
                    children: vol === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        d: "M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z"
                    }, void 0, false, {
                        fileName: "[project]/src/components/VolumeControl.tsx",
                        lineNumber: 25,
                        columnNumber: 13
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        d: "M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"
                    }, void 0, false, {
                        fileName: "[project]/src/components/VolumeControl.tsx",
                        lineNumber: 27,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/VolumeControl.tsx",
                    lineNumber: 23,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/VolumeControl.tsx",
                lineNumber: 18,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                type: "range",
                min: 0,
                max: 1,
                step: 0.05,
                value: vol,
                onChange: (e)=>onVolume(Number(e.target.value)),
                className: "w-20 h-1 bg-black/20 rounded-full appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:bg-black [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:cursor-pointer"
            }, void 0, false, {
                fileName: "[project]/src/components/VolumeControl.tsx",
                lineNumber: 33,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/VolumeControl.tsx",
        lineNumber: 16,
        columnNumber: 5
    }, this);
}
_c = VolumeControl;
var _c;
__turbopack_context__.k.register(_c, "VolumeControl");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/VideoPlayer.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "VideoPlayer",
    ()=>VideoPlayer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useVideoPlayer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useVideoPlayer.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useWatchProgress$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useWatchProgress.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$SeekBar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/SeekBar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$SpeedSelector$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/SpeedSelector.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$VolumeControl$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/VolumeControl.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
// ------------------------------------------------------------------
// drive-pleya — video player with custom controls overlay
// ------------------------------------------------------------------
"use client";
;
;
;
;
;
;
// keep a stable ref to the player API for callbacks
let _playerRef = null;
function setPlayerRef(p) {
    _playerRef = p;
}
function VideoPlayer({ src, fileId, title, initialProgress }) {
    _s();
    const videoRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const containerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const hideTimerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [showControls, setShowControls] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [resumePrompt, setResumePrompt] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const player = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useVideoPlayer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useVideoPlayer"])(videoRef, containerRef);
    setPlayerRef(player);
    // single-click → play/pause, double-click → fullscreen
    const clickTimerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const handleVideoClick = ()=>{
        if (clickTimerRef.current) {
            clearTimeout(clickTimerRef.current);
            clickTimerRef.current = null;
            player.toggleFullscreen();
        } else {
            clickTimerRef.current = setTimeout(()=>{
                clickTimerRef.current = null;
                player.togglePlay();
            }, 250);
        }
    };
    // watch progress
    const { saveOnPause } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useWatchProgress$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWatchProgress"])({
        fileId,
        videoRef,
        onProgressLoaded: {
            "VideoPlayer.useWatchProgress": (p)=>{
                if (p && p.position > 5 && !p.completed) setResumePrompt(true);
            }
        }["VideoPlayer.useWatchProgress"]
    });
    // auto-hide controls
    const scheduleHide = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "VideoPlayer.useCallback[scheduleHide]": ()=>{
            if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
            hideTimerRef.current = setTimeout({
                "VideoPlayer.useCallback[scheduleHide]": ()=>setShowControls(false)
            }["VideoPlayer.useCallback[scheduleHide]"], 3000);
        }
    }["VideoPlayer.useCallback[scheduleHide]"], []);
    const resetHideTimer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "VideoPlayer.useCallback[resetHideTimer]": ()=>{
            setShowControls(true);
            if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
            if (player.playing) scheduleHide();
        }
    }["VideoPlayer.useCallback[resetHideTimer]"], [
        player.playing,
        scheduleHide
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "VideoPlayer.useEffect": ()=>{
            if (player.playing) {
                scheduleHide();
            } else {
                setShowControls(true);
                if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
            }
            return ({
                "VideoPlayer.useEffect": ()=>{
                    if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
                }
            })["VideoPlayer.useEffect"];
        }
    }["VideoPlayer.useEffect"], [
        player.playing,
        scheduleHide
    ]);
    // keyboard shortcuts
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "VideoPlayer.useEffect": ()=>{
            const handler = {
                "VideoPlayer.useEffect.handler": (e)=>{
                    const p = _playerRef;
                    if (!p) return;
                    if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
                    switch(e.key){
                        case " ":
                        case "k":
                            e.preventDefault();
                            p.togglePlay();
                            break;
                        case "ArrowLeft":
                        case "j":
                            e.preventDefault();
                            p.skip(-5);
                            break;
                        case "ArrowRight":
                        case "l":
                            e.preventDefault();
                            p.skip(5);
                            break;
                        case "ArrowUp":
                            e.preventDefault();
                            p.setVolume(Math.min(1, p.volume + 0.1));
                            break;
                        case "ArrowDown":
                            e.preventDefault();
                            p.setVolume(Math.max(0, p.volume - 0.1));
                            break;
                        case "m":
                            p.toggleMute();
                            break;
                        case "f":
                            p.toggleFullscreen();
                            break;
                        case ">":
                        case ".":
                            p.cycleSpeed(1);
                            break;
                        case "<":
                        case ",":
                            p.cycleSpeed(-1);
                            break;
                        default:
                            if (e.key >= "0" && e.key <= "9") {
                                e.preventDefault();
                                p.seek(Number(e.key) / 10 * p.duration);
                            }
                    }
                }
            }["VideoPlayer.useEffect.handler"];
            window.addEventListener("keydown", handler);
            return ({
                "VideoPlayer.useEffect": ()=>window.removeEventListener("keydown", handler)
            })["VideoPlayer.useEffect"];
        }
    }["VideoPlayer.useEffect"], []);
    // render
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: containerRef,
        className: "relative bg-black rounded-lg overflow-hidden group/player",
        onMouseMove: resetHideTimer,
        onMouseLeave: ()=>player.playing && setShowControls(false),
        onTouchStart: ()=>{
            // tap anywhere on the player to toggle controls on mobile
            if (!showControls) setShowControls(true);
            else resetHideTimer();
        },
        children: [
            resumePrompt && initialProgress && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute top-4 left-1/2 -translate-x-1/2 z-40 bg-surface-card border border-border rounded-lg px-4 py-3 shadow-xl",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-text mb-2",
                        children: [
                            "resume from ",
                            fmtTime(initialProgress.position),
                            "?"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/VideoPlayer.tsx",
                        lineNumber: 128,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>{
                                    setResumePrompt(false);
                                    videoRef.current?.play();
                                },
                                className: "px-3 py-1 text-xs font-medium bg-brand text-white rounded hover:bg-brand-hover transition-colors",
                                children: "resume"
                            }, void 0, false, {
                                fileName: "[project]/src/components/VideoPlayer.tsx",
                                lineNumber: 130,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>{
                                    setResumePrompt(false);
                                    if (videoRef.current) videoRef.current.currentTime = 0;
                                },
                                className: "px-3 py-1 text-xs text-text-muted hover:text-text transition-colors",
                                children: "start over"
                            }, void 0, false, {
                                fileName: "[project]/src/components/VideoPlayer.tsx",
                                lineNumber: 136,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/VideoPlayer.tsx",
                        lineNumber: 129,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/VideoPlayer.tsx",
                lineNumber: 127,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute inset-0 flex items-center justify-center z-30 pointer-events-none",
                children: player.buffering ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "h-12 w-12 animate-spin rounded-full border-2 border-white/30 border-t-white"
                }, void 0, false, {
                    fileName: "[project]/src/components/VideoPlayer.tsx",
                    lineNumber: 149,
                    columnNumber: 11
                }, this) : !player.playing ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: player.togglePlay,
                    className: "pointer-events-auto h-16 w-16 flex items-center justify-center rounded-full bg-white/90 text-black hover:bg-white hover:scale-110 transition-transform",
                    "aria-label": "play",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                        className: "w-7 h-7 ml-1",
                        fill: "currentColor",
                        viewBox: "0 0 24 24",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M8 5v14l11-7z"
                        }, void 0, false, {
                            fileName: "[project]/src/components/VideoPlayer.tsx",
                            lineNumber: 157,
                            columnNumber: 15
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/VideoPlayer.tsx",
                        lineNumber: 156,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/VideoPlayer.tsx",
                    lineNumber: 151,
                    columnNumber: 11
                }, this) : null
            }, void 0, false, {
                fileName: "[project]/src/components/VideoPlayer.tsx",
                lineNumber: 147,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("video", {
                ref: videoRef,
                src: src,
                className: "w-full cursor-pointer",
                onClick: handleVideoClick,
                onPause: ()=>saveOnPause(),
                preload: "metadata",
                playsInline: true,
                crossOrigin: "anonymous"
            }, void 0, false, {
                fileName: "[project]/src/components/VideoPlayer.tsx",
                lineNumber: 164,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `controls-overlay absolute bottom-0 left-0 right-0 bg-gradient-to-t from-white/95 via-white/80 to-transparent px-3 sm:px-4 pt-10 sm:pt-12 pb-2 sm:pb-3 transition-opacity duration-300 ${showControls ? "opacity-100" : "opacity-0 pointer-events-none"}`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$SeekBar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SeekBar"], {
                        currentTime: player.currentTime,
                        duration: player.duration,
                        onSeek: player.seek
                    }, void 0, false, {
                        fileName: "[project]/src/components/VideoPlayer.tsx",
                        lineNumber: 181,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-between mt-1 gap-1 sm:gap-0",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-1 sm:gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>player.skip(-5),
                                        className: "h-8 sm:h-8 w-8 sm:w-8 flex items-center justify-center rounded text-black hover:text-gray-700 transition-colors",
                                        title: "back 5s",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                            className: "w-5 h-5",
                                            fill: "currentColor",
                                            viewBox: "0 0 24 24",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                d: "M12.5 8c-2.65 0-5.05.99-6.9 2.6L2 7v9h9l-3.62-3.62c1.39-1.16 3.16-1.88 5.12-1.88 3.54 0 6.55 2.31 7.6 5.5l2.37-.78C21.08 11.03 17.15 8 12.5 8z"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/VideoPlayer.tsx",
                                                lineNumber: 188,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/VideoPlayer.tsx",
                                            lineNumber: 187,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/VideoPlayer.tsx",
                                        lineNumber: 186,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: player.togglePlay,
                                        className: "h-10 sm:h-10 w-10 sm:w-10 flex items-center justify-center rounded-full bg-white text-black hover:bg-gray-200 transition-colors",
                                        title: player.playing ? "pause" : "play",
                                        children: player.playing ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                            className: "w-5 h-5",
                                            fill: "currentColor",
                                            viewBox: "0 0 24 24",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                d: "M6 19h4V5H6v14zm8-14v14h4V5h-4z"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/VideoPlayer.tsx",
                                                lineNumber: 194,
                                                columnNumber: 82
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/VideoPlayer.tsx",
                                            lineNumber: 194,
                                            columnNumber: 17
                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                            className: "w-5 h-5",
                                            fill: "currentColor",
                                            viewBox: "0 0 24 24",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                d: "M8 5v14l11-7z"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/VideoPlayer.tsx",
                                                lineNumber: 196,
                                                columnNumber: 82
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/VideoPlayer.tsx",
                                            lineNumber: 196,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/VideoPlayer.tsx",
                                        lineNumber: 192,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>player.skip(5),
                                        className: "h-8 sm:h-8 w-8 sm:w-8 flex items-center justify-center rounded text-black hover:text-gray-700 transition-colors",
                                        title: "forward 5s",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                            className: "w-5 h-5",
                                            fill: "currentColor",
                                            viewBox: "0 0 24 24",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                d: "M18 13c0 3.31-2.69 6-6 6s-6-2.69-6-6 2.69-6 6-6v4l5-5-5-5v4c-4.42 0-8 3.58-8 8s3.58 8 8 8 8-3.58 8-8h-2z"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/VideoPlayer.tsx",
                                                lineNumber: 202,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/VideoPlayer.tsx",
                                            lineNumber: 201,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/VideoPlayer.tsx",
                                        lineNumber: 200,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-[11px] sm:text-xs text-gray-700 ml-1 sm:ml-2 tabular-nums min-w-[70px] sm:min-w-[80px]",
                                        children: [
                                            fmtTime(player.currentTime),
                                            " / ",
                                            fmtTime(player.duration)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/VideoPlayer.tsx",
                                        lineNumber: 206,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/VideoPlayer.tsx",
                                lineNumber: 185,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-1 sm:gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$VolumeControl$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VolumeControl"], {
                                        volume: player.volume,
                                        muted: player.muted,
                                        onVolume: player.setVolume,
                                        onToggleMute: player.toggleMute
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/VideoPlayer.tsx",
                                        lineNumber: 213,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$SpeedSelector$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SpeedSelector"], {
                                        speed: player.speed,
                                        speeds: player.SPEEDS,
                                        onChange: player.setSpeed
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/VideoPlayer.tsx",
                                        lineNumber: 214,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: player.toggleFullscreen,
                                        className: "h-8 sm:h-8 w-8 sm:w-8 flex items-center justify-center rounded text-black hover:text-gray-700 transition-colors",
                                        title: "fullscreen",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                            className: "w-4 h-4",
                                            fill: "none",
                                            viewBox: "0 0 24 24",
                                            stroke: "currentColor",
                                            strokeWidth: 2,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round",
                                                d: "M8 3H5a2 2 0 00-2 2v3m18 0V5a2 2 0 00-2-2h-3m0 18h3a2 2 0 002-2v-3M3 16v3a2 2 0 002 2h3"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/VideoPlayer.tsx",
                                                lineNumber: 217,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/VideoPlayer.tsx",
                                            lineNumber: 216,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/VideoPlayer.tsx",
                                        lineNumber: 215,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/VideoPlayer.tsx",
                                lineNumber: 212,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/VideoPlayer.tsx",
                        lineNumber: 183,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/VideoPlayer.tsx",
                lineNumber: 176,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/VideoPlayer.tsx",
        lineNumber: 114,
        columnNumber: 5
    }, this);
}
_s(VideoPlayer, "dbHpy55Y7SHxgc4sUpLs+guPwZk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useVideoPlayer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useVideoPlayer"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useWatchProgress$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWatchProgress"]
    ];
});
_c = VideoPlayer;
function fmtTime(seconds) {
    if (!isFinite(seconds) || seconds < 0) return "0:00";
    const h = Math.floor(seconds / 3600);
    const m = Math.floor(seconds % 3600 / 60);
    const s = Math.floor(seconds % 60);
    if (h > 0) return `${h}:${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
    return `${m}:${s.toString().padStart(2, "0")}`;
}
var _c;
__turbopack_context__.k.register(_c, "VideoPlayer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ThumbnailImg.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ThumbnailImg",
    ()=>ThumbnailImg
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/api.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
// ------------------------------------------------------------------
// drive-pleya — shared thumbnail image with 2-stage fallback
// ------------------------------------------------------------------
"use client";
;
;
function ThumbnailImg({ file, className = "", iconSize = "md" }) {
    _s();
    const { id, name, thumbnailLink } = file;
    // 0 = direct Google CDN, 1 = backend proxy, 2 = placeholder
    const [stage, setStage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(thumbnailLink ? 0 : 1);
    // When we have no thumbnailLink AND the proxy already failed, or both
    // direct + proxy attempts failed, show the placeholder.
    if (stage >= 2 || !thumbnailLink && stage >= 1 && stage >= 2) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: `flex items-center justify-center text-text-muted ${className}`,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                className: iconSize === "sm" ? "w-6 h-6" : "w-10 h-10",
                fill: "none",
                viewBox: "0 0 24 24",
                stroke: "currentColor",
                strokeWidth: 1.5,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    d: "M5.25 5.653c0-.856.917-1.398 1.667-.986l11.54 6.348a1.125 1.125 0 010 1.971l-11.54 6.347c-.75.412-1.667-.13-1.667-.986V5.653z"
                }, void 0, false, {
                    fileName: "[project]/src/components/ThumbnailImg.tsx",
                    lineNumber: 38,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/ThumbnailImg.tsx",
                lineNumber: 31,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/ThumbnailImg.tsx",
            lineNumber: 30,
            columnNumber: 7
        }, this);
    }
    const src = stage === 0 && thumbnailLink ? thumbnailLink : __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["api"].getThumbnailUrl(id);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
        src: src,
        alt: name,
        className: `object-cover ${className}`,
        loading: "lazy",
        onError: ()=>setStage((s)=>s < 2 ? s + 1 : 2)
    }, void 0, false, {
        fileName: "[project]/src/components/ThumbnailImg.tsx",
        lineNumber: 54,
        columnNumber: 5
    }, this);
}
_s(ThumbnailImg, "Kewh2kUle81Iqqx2QmFE6eFITcY=");
_c = ThumbnailImg;
var _c;
__turbopack_context__.k.register(_c, "ThumbnailImg");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/PlaylistSidebar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PlaylistSidebar",
    ()=>PlaylistSidebar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/format.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ThumbnailImg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ThumbnailImg.tsx [app-client] (ecmascript)");
// ------------------------------------------------------------------
// drive-pleya — playlist sidebar (YouTube-style video list)
// ------------------------------------------------------------------
"use client";
;
;
;
;
function PlaylistSidebar({ files, currentId }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col gap-0.5 max-h-[80vh] overflow-y-auto",
        children: files.map((f, i)=>{
            const isActive = f.id === currentId;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                href: `/watch/${encodeURIComponent(f.id)}`,
                className: `flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${isActive ? "bg-brand/10 border border-brand/30" : "hover:bg-surface-raised border border-transparent"}`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: `w-6 text-center text-xs font-mono flex-shrink-0 ${isActive ? "text-brand font-bold" : "text-text-muted"}`,
                        children: isActive ? "▶" : i + 1
                    }, void 0, false, {
                        fileName: "[project]/src/components/PlaylistSidebar.tsx",
                        lineNumber: 33,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-28 flex-shrink-0 aspect-video bg-surface-card rounded overflow-hidden",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ThumbnailImg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ThumbnailImg"], {
                            file: f,
                            className: "w-full h-full",
                            iconSize: "sm"
                        }, void 0, false, {
                            fileName: "[project]/src/components/PlaylistSidebar.tsx",
                            lineNumber: 43,
                            columnNumber: 15
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/PlaylistSidebar.tsx",
                        lineNumber: 42,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "min-w-0 flex-1",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: `text-sm truncate font-medium ${isActive ? "text-brand" : "text-text"}`,
                            children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatTitle"])(f.name)
                        }, void 0, false, {
                            fileName: "[project]/src/components/PlaylistSidebar.tsx",
                            lineNumber: 48,
                            columnNumber: 15
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/PlaylistSidebar.tsx",
                        lineNumber: 47,
                        columnNumber: 13
                    }, this)
                ]
            }, f.id, true, {
                fileName: "[project]/src/components/PlaylistSidebar.tsx",
                lineNumber: 23,
                columnNumber: 11
            }, this);
        })
    }, void 0, false, {
        fileName: "[project]/src/components/PlaylistSidebar.tsx",
        lineNumber: 19,
        columnNumber: 5
    }, this);
}
_c = PlaylistSidebar;
var _c;
__turbopack_context__.k.register(_c, "PlaylistSidebar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/UiState.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "UiState",
    ()=>UiState
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// ------------------------------------------------------------------
// drive-pleya — unified loading / error / empty state component
// ------------------------------------------------------------------
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/api.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
function UiState({ status, loadingMessage = "loading...", errorMessage = "something went wrong", emptyMessage = "nothing here", error, onRetry, children }) {
    _s();
    // ---- auto-retry for cold starts ----
    const retryCountRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0);
    const [retrying, setRetrying] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const isColdStart = error instanceof __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ApiError"] && error.coldStart;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "UiState.useEffect": ()=>{
            if (!isColdStart || !onRetry) return;
            retryCountRef.current = 0;
            setRetrying(true);
            // retry every 6 seconds, up to 8 times (~48 seconds total)
            const interval = setInterval({
                "UiState.useEffect.interval": ()=>{
                    retryCountRef.current++;
                    if (retryCountRef.current >= 8) {
                        clearInterval(interval);
                        setRetrying(false);
                        return;
                    }
                    onRetry();
                }
            }["UiState.useEffect.interval"], 6_000);
            return ({
                "UiState.useEffect": ()=>clearInterval(interval)
            })["UiState.useEffect"];
        }
    }["UiState.useEffect"], [
        isColdStart,
        onRetry
    ]);
    // ---- loading ----
    if (status === "loading") {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col items-center justify-center py-24 gap-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "h-8 w-8 animate-spin rounded-full border-2 border-border border-t-brand"
                }, void 0, false, {
                    fileName: "[project]/src/components/UiState.tsx",
                    lineNumber: 60,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-text-muted text-sm",
                    children: loadingMessage
                }, void 0, false, {
                    fileName: "[project]/src/components/UiState.tsx",
                    lineNumber: 61,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/UiState.tsx",
            lineNumber: 59,
            columnNumber: 7
        }, this);
    }
    // ---- cold start (error, but specifically a Render wake-up) ----
    if (status === "error" && isColdStart) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col items-center justify-center py-24 gap-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "h-10 w-10 animate-spin rounded-full border-2 border-border border-t-brand"
                }, void 0, false, {
                    fileName: "[project]/src/components/UiState.tsx",
                    lineNumber: 70,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-text text-sm font-medium",
                    children: "waking up the server..."
                }, void 0, false, {
                    fileName: "[project]/src/components/UiState.tsx",
                    lineNumber: 71,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-text-muted text-xs text-center max-w-sm",
                    children: [
                        "the backend is hosted on a free tier that sleeps after inactivity.",
                        retrying ? ` auto-retrying (${retryCountRef.current + 1}/8)...` : " this may take up to a minute."
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/UiState.tsx",
                    lineNumber: 72,
                    columnNumber: 9
                }, this),
                !retrying && onRetry && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: ()=>{
                        retryCountRef.current = 0;
                        setRetrying(true);
                        onRetry();
                    },
                    className: "mt-2 rounded-lg bg-surface-raised border border-border px-4 py-2 text-sm text-text hover:bg-surface-card transition-colors",
                    children: "retry"
                }, void 0, false, {
                    fileName: "[project]/src/components/UiState.tsx",
                    lineNumber: 79,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/UiState.tsx",
            lineNumber: 69,
            columnNumber: 7
        }, this);
    }
    // ---- error (generic) ----
    if (status === "error") {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col items-center justify-center py-24 gap-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-4xl",
                    children: "⚠"
                }, void 0, false, {
                    fileName: "[project]/src/components/UiState.tsx",
                    lineNumber: 94,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-text-muted text-sm",
                    children: errorMessage
                }, void 0, false, {
                    fileName: "[project]/src/components/UiState.tsx",
                    lineNumber: 95,
                    columnNumber: 9
                }, this),
                onRetry && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: onRetry,
                    className: "mt-2 rounded-lg bg-surface-raised border border-border px-4 py-2 text-sm text-text hover:bg-surface-card transition-colors",
                    children: "retry"
                }, void 0, false, {
                    fileName: "[project]/src/components/UiState.tsx",
                    lineNumber: 97,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/UiState.tsx",
            lineNumber: 93,
            columnNumber: 7
        }, this);
    }
    // ---- empty ----
    if (status === "empty") {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col items-center justify-center py-24 gap-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-4xl",
                    children: "📁"
                }, void 0, false, {
                    fileName: "[project]/src/components/UiState.tsx",
                    lineNumber: 112,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-text-muted text-sm",
                    children: emptyMessage
                }, void 0, false, {
                    fileName: "[project]/src/components/UiState.tsx",
                    lineNumber: 113,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/UiState.tsx",
            lineNumber: 111,
            columnNumber: 7
        }, this);
    }
    // success — render children
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: children
    }, void 0, false);
}
_s(UiState, "oVIfPfNcigZ51gJP5DYneBldtvc=");
_c = UiState;
var _c;
__turbopack_context__.k.register(_c, "UiState");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/watch/[id]/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>WatchPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$progressStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/progressStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/format.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$VideoPlayer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/VideoPlayer.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PlaylistSidebar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/PlaylistSidebar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$UiState$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/UiState.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
// ------------------------------------------------------------------
// drive-pleya — watch page (video player + playlist sidebar)
// ------------------------------------------------------------------
"use client";
;
;
;
;
;
;
;
;
function WatchPage({ params }) {
    _s();
    const { id } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["use"])(params);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [file, setFile] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [allFiles, setAllFiles] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [progress, setProgress] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])();
    const [status, setStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("loading");
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "WatchPage.useEffect": ()=>{
            let cancelled = false;
            async function load() {
                setStatus("loading");
                try {
                    const [f, list] = await Promise.all([
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["api"].getFile(id),
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["api"].getFiles().then({
                            "WatchPage.useEffect.load": (r)=>r.files
                        }["WatchPage.useEffect.load"])
                    ]);
                    const p = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$progressStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["progressStore"].get(id);
                    if (cancelled) return;
                    setFile(f);
                    setAllFiles(list);
                    setProgress(p ?? undefined);
                    setStatus("success");
                } catch (err) {
                    if (cancelled) return;
                    setError(err);
                    setStatus("error");
                }
            }
            load();
            return ({
                "WatchPage.useEffect": ()=>{
                    cancelled = true;
                }
            })["WatchPage.useEffect"];
        }
    }["WatchPage.useEffect"], [
        id
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$UiState$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UiState"], {
        status: status,
        loadingMessage: "loading video...",
        errorMessage: error instanceof Error ? error.message : "failed to load video",
        error: error,
        onRetry: ()=>router.refresh(),
        children: file && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col xl:flex-row gap-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex-1 min-w-0 flex flex-col gap-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$VideoPlayer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VideoPlayer"], {
                            src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["api"].getStreamUrl(file.id),
                            fileId: file.id,
                            title: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatTitle"])(file.name),
                            initialProgress: progress
                        }, void 0, false, {
                            fileName: "[project]/src/app/watch/[id]/page.tsx",
                            lineNumber: 72,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "text-lg font-semibold text-text",
                                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatTitle"])(file.name)
                                }, void 0, false, {
                                    fileName: "[project]/src/app/watch/[id]/page.tsx",
                                    lineNumber: 81,
                                    columnNumber: 15
                                }, this),
                                file.modifiedTime && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-xs text-text-muted mt-1",
                                    children: [
                                        "modified",
                                        " ",
                                        new Date(file.modifiedTime).toLocaleDateString("en-US", {
                                            year: "numeric",
                                            month: "short",
                                            day: "numeric"
                                        })
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/watch/[id]/page.tsx",
                                    lineNumber: 85,
                                    columnNumber: 17
                                }, this),
                                file.size > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-xs text-text-muted",
                                    children: formatSize(file.size)
                                }, void 0, false, {
                                    fileName: "[project]/src/app/watch/[id]/page.tsx",
                                    lineNumber: 95,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/watch/[id]/page.tsx",
                            lineNumber: 80,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>router.push("/"),
                            className: "text-sm text-text-muted hover:text-text transition-colors",
                            children: "← back to library"
                        }, void 0, false, {
                            fileName: "[project]/src/app/watch/[id]/page.tsx",
                            lineNumber: 100,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/watch/[id]/page.tsx",
                    lineNumber: 71,
                    columnNumber: 11
                }, this),
                allFiles.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "xl:w-80 xl:flex-shrink-0 w-full",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PlaylistSidebar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PlaylistSidebar"], {
                        files: allFiles,
                        currentId: file.id
                    }, void 0, false, {
                        fileName: "[project]/src/app/watch/[id]/page.tsx",
                        lineNumber: 111,
                        columnNumber: 15
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/watch/[id]/page.tsx",
                    lineNumber: 110,
                    columnNumber: 13
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/watch/[id]/page.tsx",
            lineNumber: 69,
            columnNumber: 9
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/watch/[id]/page.tsx",
        lineNumber: 61,
        columnNumber: 5
    }, this);
}
_s(WatchPage, "v8hmXEDLygFImJJP7sdFev78AO4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = WatchPage;
// ------------------------------------------------------------------
// helpers
// ------------------------------------------------------------------
function formatSize(bytes) {
    const mb = bytes / (1024 * 1024);
    if (mb >= 1000) return `${(mb / 1024).toFixed(1)} GB`;
    return `${mb.toFixed(0)} MB`;
}
var _c;
__turbopack_context__.k.register(_c, "WatchPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_0mute77._.js.map